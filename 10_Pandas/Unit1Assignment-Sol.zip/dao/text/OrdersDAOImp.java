package dao.text;

import common.Constants;
import common.configuration.Configuration;
import io.vavr.control.Either;
import model.Customer;
import model.Order;
import model.errors.CommonError;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static java.nio.file.StandardOpenOption.TRUNCATE_EXISTING;
import static java.nio.file.StandardOpenOption.WRITE;

public class OrdersDAOImp implements dao.OrdersDAO {




    @Override
    public Either<CommonError, List<Order>> getAll() {
        Either<CommonError, List<Order>> result;
        try {
            result = Either.right(getListLarge());
        } catch (Exception e) {
            result = Either.left(new CommonError(0, e.getMessage(), new Date()));
        }
        return result;
    }

    @Override
    public Either<CommonError, Order> get(int id) {
        return null;
    }

    @Override
    public Either<CommonError, Integer> add(Order o) {
        Either<CommonError, Integer> result;
        try {
            List<Order> orders = getListLarge();
            int id= getlastId() + 1;
            o.setId(id);
            orders.add(o);
            if (writeListLarge(orders)) {
                result = Either.right(id);
            }
            else result = Either.left(new CommonError(0, Constants.ERROR_ADDING_ORDER, new Date()));
        } catch (Exception e) {
            result = Either.left(new CommonError(0, e.getMessage(), new Date()));
        }
        return result;
    }

    @Override
    public Either<CommonError, Integer> update(Order o) {
        Either<CommonError, Integer> result;
        try {
            boolean enter = false;
            List<Order> orders = getListLarge();
            for (int i = 0; i < orders.size(); i++) {
                Order or = orders.get(i);
                if (or.getId().equals(o.getId())) {
                    orders.set(i, o);
                    enter = true;
                    break;
                }
            }
            if (enter) writeListLarge(orders);
            result = Either.right(orders.size());
        } catch (Exception e) {
            result = Either.left(new CommonError(0, e.getMessage(), new Date()));
        }
        return result;
    }

    @Override
    public Either<CommonError, Integer> delete(Order o) {
        Either<CommonError, Integer> result;
        try {
            List<Order> orders = getListLarge();
            if (orders.remove(o) && writeListLarge(orders)) {
                result = Either.right(1);
            }
            else result = Either.left(new CommonError(0, Constants.ERROR_DELETING_ORDER, new Date()));
        } catch (Exception e) {
            result = Either.left(new CommonError(0, e.getMessage(), new Date()));
        }
        return result;
    }

    private List<Order> getListLarge() throws Exception {
        Path file = Paths.get(Configuration.getInstance().getPropertyTxt(Constants.PATH_ORDERS));
        List<Order> orderList = new ArrayList<>();
        BufferedReader reader = null;
        reader = Files.newBufferedReader(file);
        String line = null;
        while ((line = reader.readLine()) != null) {
            orderList.add(new Order(line));
        }
        return orderList;
    }

    private boolean writeListLarge(List<Order> orders) {
        Path file = Paths.get(Configuration.getInstance().getPropertyTxt(Constants.PATH_ORDERS));
        OpenOption[] options = new OpenOption[2];
        options[0] = TRUNCATE_EXISTING;
        options[1] = WRITE;

        try {
            try (BufferedWriter writer = Files.newBufferedWriter(file, options)) {
                for (int i = 0; i < orders.size(); i++) {
                    writer.write(orders.get(i).toString(), 0, orders.get(i).toString().length());
                    if (i != orders.size() - 1) {
                        writer.newLine();
                    }
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return true;
    }

    private int getlastId() throws Exception{
        List<Order> orders = getListLarge();
        if(!orders.isEmpty() ) {
            int lastIndex = orders.size() - 1;
            return orders.get(lastIndex).getId();
        }
        else return 0;
    }
}
