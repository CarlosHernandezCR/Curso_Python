package dao.text;

import common.Constants;
import model.Credentials;

public class CredentialsDAO implements dao.CredentialsDAO {

    @Override
    public Credentials getLogin(){
        return new Credentials(Constants.ROOT, Constants.DAM);
    }
}
