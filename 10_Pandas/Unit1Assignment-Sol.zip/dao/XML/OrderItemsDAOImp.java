package dao.XML;

import common.Constants;
import common.configuration.Configuration;
import dao.OrderItemDAO;
import io.vavr.control.Either;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;
import jakarta.xml.bind.Unmarshaller;
import model.MenuItem;
import model.OrderItem;
import model.XML.OrderItemXML;
import model.XML.OrderXML;
import model.XML.OrdersXML;
import model.errors.CommonError;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


public class OrderItemsDAOImp implements OrderItemDAO {
    private Unmarshaller unmarshaller;
    private JAXBContext context;
    private Marshaller marshaller;
    private Path xmlFile;

    public OrderItemsDAOImp() {
        try {
            context = JAXBContext.newInstance(OrdersXML.class);
            unmarshaller = context.createUnmarshaller();
            marshaller = context.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            xmlFile = Paths.get(Configuration.getInstance().getPropertyXml(Constants.XML_ORDERS_PATH));
        } catch (JAXBException ignored) {
        }

    }

    public Either<CommonError, List<OrderItem>> getAll() {
        Either<CommonError, List<OrderItem>> result = null;
        try {
            result = Either.right(parseItemOrders(readFileXML()));
        } catch (Exception e) {
            result = Either.left(new CommonError(0, e.getMessage(), new Date()));
        }
        return result;
    }

    @Override
    public Either<CommonError, OrderItem> get(int id) {
        return null;
    }

    @Override
    public Either<CommonError, Integer> add(OrderItem i) {
        Either<CommonError, Integer> result;
        try {
            List<OrderItem> modifyList = parseItemOrders(readFileXML());
            modifyList.add(i);
            if (writeFileXML(parseOrdersXML(modifyList)))
                result = Either.right(modifyList.size());
            else result = Either.left(new CommonError(0, Constants.ERROR_ADDING_ORDERITEM, new Date()));
        } catch (Exception e) {
            result = Either.left(new CommonError(0, e.getMessage(), new Date()));
        }
        return result;
    }

    @Override
    public Either<CommonError, Integer> update(OrderItem i) {
        Either<CommonError, Integer> result;
        try {
            List<OrderItem> modifyList = parseItemOrders(readFileXML());
            boolean enter = false;
            for (int x = 0; x < modifyList.size(); x++) {
                OrderItem oi = modifyList.get(x);
                if (oi.getOrderId().equals(i.getOrderId())) {
                    modifyList.set(x, i);
                    enter = true;
                    break;
                }
            }
            if (enter) writeFileXML(parseOrdersXML(modifyList));
            result = Either.right(modifyList.size());
        } catch (Exception e) {
            result = Either.left(new CommonError(0, e.getMessage(), new Date()));
        }
        return result;
    }

    @Override
    public Either<CommonError, Integer> delete(OrderItem i) {
        Either<CommonError, Integer> result;
        try {
            List<OrderItem> modifyList = parseItemOrders(readFileXML());
            modifyList.remove(i);
            if (writeFileXML(parseOrdersXML(modifyList)))
                result = Either.right(modifyList.size());
            else result = Either.left(new CommonError(0, Constants.ERROR_ADDING_ORDERITEM, new Date()));
        } catch (Exception e) {
            result = Either.left(new CommonError(0, e.getMessage(), new Date()));
        }
        return result;
    }

    private OrdersXML readFileXML() throws Exception {
        return (OrdersXML) unmarshaller.unmarshal(Files.newInputStream(xmlFile));
    }

    private boolean writeFileXML(OrdersXML ordersXML) throws Exception {
        marshaller.marshal(ordersXML, Files.newOutputStream(xmlFile));
        return true;
    }

    private OrdersXML parseOrdersXML(List<OrderItem> orderItemList) {
        Map<Integer, List<OrderItem>> groupedItems = orderItemList.stream().collect(Collectors.groupingBy(orderItem -> orderItem.getOrderId()));
        OrdersXML ordersXML = new OrdersXML();
        List<OrderXML> orderXMLList = new ArrayList<>();
        ordersXML.setOrderXMLList(orderXMLList);
        for (List<OrderItem> list : groupedItems.values()) {
            OrderXML orderXML = new OrderXML();
            List<OrderItemXML> orderItemXMLList = new ArrayList<>();
            orderXML.setOrderItemsXMLList(orderItemXMLList);
            orderXML.setId(list.get(0).getOrderId());

            for (OrderItem orderItem : list) {
                OrderItemXML orderItemXML = new OrderItemXML(orderItem.getMenuItem().getName(), orderItem.getQuantity());
                orderItemXMLList.add(orderItemXML);
            }

            orderXMLList.add(orderXML);
        }
        return ordersXML;
    }


    private List<OrderItem> parseItemOrders(OrdersXML ordersXML) {
        List<OrderItem> orderItemList = new ArrayList<>();
        for (OrderXML o : ordersXML.getOrderXMLList()) {
            int idO = o.getId();
            for (OrderItemXML it : o.getOrderItemsXMLList()) {
                int quantity = it.getQuantity();
                MenuItem mn = new MenuItem(null, it.getMenuItemName(), null);
                orderItemList.add(new OrderItem(null, quantity, idO, mn));
            }
        }
        return orderItemList;
    }
}
