package model;
import lombok.*;

@Data
public class OrderItem {
    public OrderItem(Integer id, Integer quantity, Integer orderId, MenuItem menuItem) {
        this.id = id;
        this.quantity = quantity;
        this.orderId = orderId;
        this.menuItem = menuItem;
    }
    private Integer id;
    private Integer quantity;
    private Integer orderId;
    private MenuItem menuItem;
    private Double total;

    public Double getTotal() {
        if(menuItem.getPrice() != null)
        return quantity * menuItem.getPrice();
        return null;
    }

}
