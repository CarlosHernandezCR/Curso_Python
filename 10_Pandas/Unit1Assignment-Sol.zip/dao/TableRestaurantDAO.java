package dao;

import io.vavr.control.Either;
import model.TableRestaurant;

import java.util.List;

public interface TableRestaurantDAO {
    Either<Integer, List<TableRestaurant>> getAll();

    Either<Integer, TableRestaurant> get(int id);

    Either<Integer, Integer> add(TableRestaurant t);

    Either<Integer, Integer> update(TableRestaurant t);

    Either<Integer, Integer> delete(TableRestaurant t);
}
