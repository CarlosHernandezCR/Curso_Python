package model;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalDate;

@Data
@AllArgsConstructor
public class Customer {
    private Integer id;
    private String first_name;
    private String last_name;
    private String email;
    private String phone;
    private LocalDate dob;

    public Customer(String customer) {
        String[] customerAttributes = customer.split(";");
        this.id = Integer.parseInt(customerAttributes[0]);
        this.first_name = customerAttributes[1];
        this.last_name = customerAttributes[2];
        this.email = customerAttributes[3];
        this.phone = customerAttributes[4];
        String[] dateSplits = customerAttributes[5].split("-");
        int year = Integer.parseInt(dateSplits[0]);
        int month = Integer.parseInt(dateSplits[1]);
        int day = Integer.parseInt(dateSplits[2]);
        dob = LocalDate.of(year, month, day);
    }
    @Override
    public String toString() {
        return id + ";" + first_name + ";" + last_name + ";" + email + ";" + phone + ";" + dob.toString();
    }

}
