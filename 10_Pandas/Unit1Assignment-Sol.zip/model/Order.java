package model;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Data
@AllArgsConstructor
public class Order {

    public Order(String order) {
        String[] orderAttributes = order.split(";");
        this.id = Integer.parseInt(orderAttributes[0]);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        this.dateTime = LocalDateTime.parse(orderAttributes[1], formatter);
        this.idCustomer = Integer.parseInt(orderAttributes[2]);
        this.idTable = Integer.parseInt(orderAttributes[3]);
    }
    private Integer id;
    private LocalDateTime dateTime;
    private Integer idCustomer;
    private Integer idTable;

    @Override
    public String toString() {
        return id + ";" + dateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")) + ";" + idCustomer + ";" + idTable;
    }
}
