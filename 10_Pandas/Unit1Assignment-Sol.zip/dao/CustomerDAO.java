package dao;

import model.errors.CommonError;
import io.vavr.control.Either;
import model.Customer;

import java.util.List;

public interface CustomerDAO {
    //crear objeto en vez de Integer
    Either<CommonError, List<Customer>> getAll();

    Either<CommonError, Customer> get(int id);

    Either<CommonError, Integer> add(Customer c);

    Either<CommonError, Integer> update(Customer c);

    Either<CommonError, Integer> delete(Customer c);
}
