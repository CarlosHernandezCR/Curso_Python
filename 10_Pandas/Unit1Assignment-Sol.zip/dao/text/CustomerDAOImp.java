package dao.text;

import common.Constants;
import common.configuration.Configuration;
import io.vavr.control.Either;
import model.Customer;
import model.errors.CommonError;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CustomerDAOImp implements dao.CustomerDAO {

    @Override
    public Either<CommonError, List<Customer>> getAll() {
        Either<CommonError, List<Customer>> result;
        try {
            result = Either.right(getListSmall());
        } catch (Exception e) {
            result = Either.left(new CommonError(0, e.getMessage(), new Date()));
        }
        return result;
    }

    @Override
    public Either<CommonError, Customer> get(int id) {
        Either<CommonError, Customer> result;
        try {
            List<Customer> list = getListSmall();
            Customer c = list.stream().filter(customer -> customer.getId() == id).toList().get(0);
            result = Either.right(c);

        } catch (Exception e) {
            result = Either.left(new CommonError(0, Constants.NO_CUSTOMER_ID, new Date()));
        }
        return result;
    }

    @Override
    public Either<CommonError, Integer> add(Customer c) {
        Either<CommonError, Integer> result;
        try {
            List<Customer> list = getListSmall();
            int id = getlastId() + 1;
            c.setId(id);
            list.add(c);
            if (writeListSmall(list)) {
                result = Either.right(list.size());
            } else {
                result = Either.left(new CommonError(0, Constants.ERROR_ADDING_CUSTOMER, new Date()));
            }
        } catch (Exception e) {
            result = Either.left(new CommonError(0, e.getMessage(), new Date()));
        }
        return result;
    }

    @Override
    public Either<CommonError, Integer> update(Customer c) {
        Either<CommonError, Integer> result;
        try {
            boolean enter = false;
            List<Customer> list = getListSmall();
            for (int i = 0; i < list.size(); i++) {
                Customer cus = list.get(i);
                if (cus.getId().equals(c.getId())) {
                    list.set(i, c);
                    enter = true;
                    break;
                }
            }
            if (enter) writeListSmall(list);
            result = Either.right(list.size());
        } catch (Exception e) {
            result = Either.left(new CommonError(0, e.getMessage(), new Date()));
        }
        return result;
    }

    @Override
    public Either<CommonError, Integer> delete(Customer c) {
        Either<CommonError, Integer> result;
        try {
            List<Customer> list = getListSmall();
            if (list.remove(c) && writeListSmall(list)) {
                result = Either.right(1);
            } else {
                result = Either.left(new CommonError(0, Constants.ERROR_DELETING_CUSTOMER, new Date()));
            }
        } catch (Exception e) {
            result = Either.left(new CommonError(0, Constants.ERROR_DELETING_CUSTOMER, new Date()));
        }

        return result;
    }

    private List<Customer> getListSmall() throws Exception {
        List<Customer> customerList = new ArrayList<>();
        Path file = Paths.get(Configuration.getInstance().getPropertyTxt(Constants.PATH_CUSTOMERS));
        List<String> fileList;
        fileList = Files.readAllLines(file);
        fileList.forEach((linea) -> {
            customerList.add(new Customer(linea));
        });

        return customerList;
    }

    private boolean writeListSmall(List<Customer> list) throws Exception {
        Path file = Paths.get(Configuration.getInstance().getPropertyTxt(Constants.PATH_CUSTOMERS));
        Files.write(file, new byte[0], StandardOpenOption.TRUNCATE_EXISTING);
        for (int i = 0; i < list.size(); i++) {
            String write;
            if (i == list.size() - 1) {
                write = list.get(i).toString();
            } else {
                write = list.get(i).toString() + "\n";
            }
            Files.write(file, write.getBytes(), StandardOpenOption.APPEND);
        }
        return true;
    }

    private int getlastId() throws Exception {
        List<Customer> customers = getListSmall();
        if (!customers.isEmpty()) {
            int lastIndex = customers.size() - 1;
            return customers.get(lastIndex).getId();
        } else return 0;
    }

}
