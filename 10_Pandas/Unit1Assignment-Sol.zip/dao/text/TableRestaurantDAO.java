package dao.text;

import io.vavr.control.Either;
import model.TableRestaurant;

import java.util.List;

public class TableRestaurantDAO implements dao.TableRestaurantDAO {
    @Override
    public Either<Integer, List<TableRestaurant>> getAll() {
        return null;
    }

    @Override
    public Either<Integer, TableRestaurant> get(int id) {
        return null;
    }

    @Override
    public Either<Integer, Integer> add(TableRestaurant t) {
        return null;
    }

    @Override
    public Either<Integer, Integer> update(TableRestaurant t) {
        return null;
    }

    @Override
    public Either<Integer, Integer> delete(TableRestaurant t) {
        return null;
    }
}
