package model.XML;


import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.util.ArrayList;
import java.util.List;

@Data
@XmlRootElement(name = "orders")
@XmlAccessorType(XmlAccessType.FIELD)
@AllArgsConstructor
public class OrdersXML {
    public OrdersXML() {
    }

    @XmlElement(name = "order")
    private List<OrderXML> orderXMLList;
}
