package dao;

import model.Credentials;

public interface CredentialsDAO {
    Credentials getLogin();
}
