package dao;

import io.vavr.control.Either;
import model.OrderItem;
import model.errors.CommonError;

import java.util.List;

public interface OrderItemDAO {
    Either<CommonError, List<OrderItem>> getAll();

    Either<CommonError, OrderItem> get(int id);

    Either<CommonError, Integer> add(OrderItem i);

    Either<CommonError, Integer> update(OrderItem i);

    Either<CommonError, Integer> delete(OrderItem i);

}
