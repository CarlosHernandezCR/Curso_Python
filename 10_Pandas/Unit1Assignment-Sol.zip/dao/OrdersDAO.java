package dao;

import model.errors.CommonError;
import io.vavr.control.Either;
import model.Order;

import java.util.List;

public interface OrdersDAO {
    Either<CommonError, List<Order>> getAll();

    Either<CommonError, Order> get(int id);

    Either<CommonError, Integer> add(Order o);

    Either<CommonError, Integer> update(Order o);

    Either<CommonError, Integer> delete(Order o);
}
